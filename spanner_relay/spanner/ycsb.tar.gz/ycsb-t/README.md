# How to run

Typing `./run-tapir` on the commandline will build the tapir binding and
execute the load, run experiments.

Make sure the server replicas are running before you execute this script.

The parameters for the experiment can be edited in `run-tapir.sh`.

The output will be stored in load.log and run.log.
